<%@page import="java.util.List"%>
<%@page import="model.Pedido"%>

<style>
body{
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:linear-gradient(135deg,#6a0dad,#8a2be2,#c71585);
    min-height:100vh;
    padding:30px;
}

.titulo{
    text-align:center;
    color:white;
    font-size:42px;
    margin-bottom:30px;
    text-shadow:2px 2px 10px rgba(0,0,0,.3);
}

.container{
    max-width:900px;
    margin:auto;
}

.item{
    background:white;
    border-radius:20px;
    padding:25px;
    margin-bottom:20px;
    box-shadow:0 10px 25px rgba(0,0,0,.15);
    transition:.3s;
}

.item:hover{
    transform:translateY(-5px);
}

.descricao{
    font-size:22px;
    color:#6a0dad;
    font-weight:bold;
}

.preco{
    font-size:24px;
    color:#333;
    margin-top:10px;
    font-weight:bold;
}

.btnRemover{
    margin-top:15px;
    border:none;
    background:linear-gradient(135deg,#ff4d4d,#cc0000);
    color:white;
    padding:12px 25px;
    border-radius:12px;
    cursor:pointer;
    font-weight:bold;
    font-size:15px;
    transition:.3s;
    box-shadow:0 5px 15px rgba(204,0,0,.4);
}

.btnRemover:hover{
    transform:translateY(-2px);
    box-shadow:0 8px 20px rgba(204,0,0,.5);
}

.totalCard{
    background:white;
    border-radius:20px;
    padding:25px;
    text-align:center;
    margin-top:25px;
    box-shadow:0 10px 25px rgba(0,0,0,.15);
}

.total{
    font-size:36px;
    color:#6a0dad;
    font-weight:bold;
}

.botoes{
    display:flex;
    gap:20px;
    justify-content:center;
    margin-top:25px;
    flex-wrap:wrap;
}

.btnContinuar{
    border:none;
    padding:15px 30px;
    border-radius:15px;
    font-size:16px;
    font-weight:bold;
    cursor:pointer;
    color:white;
    background:linear-gradient(135deg,#6a0dad,#8a2be2);
    transition:.3s;
    box-shadow:0 5px 15px rgba(106,13,173,.4);
}

.btnContinuar:hover{
    transform:translateY(-3px);
    box-shadow:0 10px 25px rgba(106,13,173,.5);
}

.btnFinalizar{
    border:none;
    padding:15px 30px;
    border-radius:15px;
    font-size:16px;
    font-weight:bold;
    cursor:pointer;
    color:white;
    background:linear-gradient(135deg,#28a745,#1e7e34);
    transition:.3s;
    box-shadow:0 5px 15px rgba(40,167,69,.4);
}

.btnFinalizar:hover{
    transform:translateY(-3px);
    box-shadow:0 10px 25px rgba(40,167,69,.5);
}
</style>

<%
    List<Pedido> lista =
            (List<Pedido>) request.getAttribute("listaPedidos");

    double total = 0;
%>

<div class="container">

    <h1 class="titulo"> Meu Carrinho</h1>

    <%
        if (lista != null) {

            for (int i = 0; i < lista.size(); i++) {

                Pedido p = lista.get(i);

                total += p.getValorTotal();
    %>

    <div class="item">

        <div class="descricao">
            <%= p.getDescricao()%>
        </div>

        <div class="preco">
            R$ <%= String.format("%.2f", p.getValorTotal()) %>
        </div>

        <form action="PedidoController" method="post">

            <input type="hidden"
                   name="op"
                   value="REMOVER">

            <input type="hidden"
                   name="indice"
                   value="<%= i%>">

            <button type="submit" class="btnRemover">
                 Remover
            </button>

        </form>

    </div>

    <%
            }
        }
    %>

    <div class="totalCard">
        <div class="total">
            Total: R$ <%= String.format("%.2f", total)%>
        </div>
    </div>

    <div class="botoes">

        <form action="index.jsp">

            <button type="submit" class="btnContinuar">
                Continuar Comprando
            </button>

        </form>

        <form action="PedidoController" method="post">

            <input type="hidden"
                   name="op"
                   value="FINALIZAR">

            <button type="submit" class="btnFinalizar">
                Finalizar Pedido
            </button>

        </form>

    </div>

</div>