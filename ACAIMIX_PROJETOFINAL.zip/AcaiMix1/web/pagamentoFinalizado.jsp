<style>
body{
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:linear-gradient(135deg,#6a0dad,#8a2be2,#c71585);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

.cardSucesso{
    background:white;
    width:500px;
    padding:40px;
    border-radius:25px;
    text-align:center;
    box-shadow:0 15px 35px rgba(0,0,0,.25);
}

.icone{
    font-size:70px;
    margin-bottom:15px;
}

.titulo{
    color:#28a745;
    font-size:36px;
    margin-bottom:20px;
}

.info{
    background:#f7f7f7;
    padding:18px;
    border-radius:15px;
    margin:15px 0;
    font-size:18px;
}

.label{
    color:#666;
    font-weight:bold;
}

.valor{
    color:#6a0dad;
    font-weight:bold;
    font-size:22px;
}

.btnNovoPedido{
    display:inline-block;
    margin-top:25px;
    padding:15px 30px;
    border-radius:15px;
    text-decoration:none;
    color:white;
    font-weight:bold;
    font-size:16px;
    background:linear-gradient(135deg,#6a0dad,#8a2be2);
    box-shadow:0 5px 20px rgba(106,13,173,.4);
    transition:.3s;
}

.btnNovoPedido:hover{
    transform:translateY(-3px);
    box-shadow:0 10px 25px rgba(106,13,173,.5);
}
</style>

<div class="cardSucesso">

    <h1 class="titulo">
        Pedido realizado com sucesso!
    </h1>

    <div class="info">
        <span class="label">Forma de pagamento:</span>
        <br><br>
        <span class="valor">
            <%= request.getAttribute("formaPagamento")%>
        </span>
    </div>

    <div class="info">
        <span class="label">Valor Total:</span>
        <br><br>
        <span class="valor">
            R$ <%= request.getAttribute("valorTotal")%>
        </span>
    </div>

    <a href="index.jsp" class="btnNovoPedido">
         Fazer Novo Pedido
    </a>

</div>