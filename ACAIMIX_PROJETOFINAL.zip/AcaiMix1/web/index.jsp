<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Acai Mix</title>

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Segoe UI',sans-serif;
        }

        body{
            min-height:100vh;
            background:linear-gradient(135deg,#6a0dad,#8a2be2,#c71585);
            display:flex;
            flex-direction:column;
        }

        #LOGO{
            background:rgba(255,255,255,0.12);
            backdrop-filter:blur(10px);
            padding:20px;
            text-align:center;
            box-shadow:0 4px 15px rgba(0,0,0,0.2);
            position:relative;
        }

        #marca{
            width:180px;
            transition:.3s;
        }

        #marca:hover{
            transform:scale(1.05);
        }

        #carrinhoArea{
            position:absolute;
            top:20px;
            right:30px;
            display:flex;
            align-items:center;
            gap:10px;
        }

        #carrinho{
            width:60px;
            height:60px;
            border:none;
            border-radius:50%;
            background:linear-gradient(135deg,#6a0dad,#8a2be2);
            cursor:pointer;
            display:flex;
            justify-content:center;
            align-items:center;
            box-shadow:0 5px 20px rgba(0,0,0,.25);
            transition:.3s;
        }

        #carrinho:hover{
            transform:translateY(-3px) scale(1.05);
            box-shadow:0 10px 25px rgba(0,0,0,.35);
        }

        #carrinho img{
            width:30px;
            height:30px;
        }

        #txtCarrinho{
            color:white;
            font-weight:bold;
            font-size:16px;
            text-shadow:1px 1px 4px rgba(0,0,0,.3);
        }

        .container{
            display:flex;
            justify-content:center;
            align-items:center;
            flex:1;
            padding:30px;
        }

        .card{
            width:650px;
            background:rgba(255,255,255,0.95);
            border-radius:25px;
            padding:35px;
            box-shadow:0 15px 40px rgba(0,0,0,0.25);
        }

        h1{
            text-align:center;
            color:#6a0dad;
            margin-bottom:10px;
            font-size:40px;
        }

        h3{
            color:#6a0dad;
            margin:25px 0 15px 0;
            font-size:22px;
            border-left:5px solid #c71585;
            padding-left:10px;
        }

        .opcao{
            display:flex;
            align-items:center;
            background:#f8f4ff;
            margin-bottom:12px;
            padding:15px;
            border-radius:15px;
            transition:.3s;
            cursor:pointer;
            border:2px solid transparent;
        }

        .opcao:hover{
            transform:translateY(-3px);
            border-color:#8a2be2;
            box-shadow:0 5px 15px rgba(106,13,173,.2);
        }

        .opcao input{
            transform:scale(1.3);
            margin-right:12px;
        }

        .opcao label{
            font-size:17px;
            font-weight:600;
            color:#333;
            cursor:pointer;
            width:100%;
        }

        .btn{
            width:100%;
            margin-top:25px;
            padding:16px;
            border:none;
            border-radius:15px;
            background:linear-gradient(135deg,#6a0dad,#c71585);
            color:white;
            font-size:17px;
            font-weight:bold;
            cursor:pointer;
            transition:.3s;
            box-shadow:0 5px 20px rgba(106,13,173,.4);
        }

        .btn:hover{
            transform:translateY(-3px);
            box-shadow:0 10px 25px rgba(106,13,173,.5);
        }

        @media(max-width:768px){

            .card{
                width:95%;
                padding:25px;
            }

            h1{
                font-size:32px;
            }

            #carrinhoArea{
                top:15px;
                right:15px;
            }

            #txtCarrinho{
                display:none;
            }
        }

    </style>
</head>

<body>

    <div id="LOGO">

        <img src="imagens/Logo.png" alt="A�aiMixLogo" id="marca">

        <div id="carrinhoArea">

            <form action="PedidoController" method="post">

                <input type="hidden"
                       name="op"
                       value="VER_CARRINHO">

                <button type="submit" id="carrinho">
                    <img src="imagens/carrinho.png" alt="Carrinho">
                </button>

            </form>

            <label id="txtCarrinho">
                CARRINHO
            </label>

        </div>

    </div>

    <div class="container">

        <div class="card">

            <h1>Monte seu Acai</h1>

            <form action="PedidoController" method="post">

                <input type="hidden" name="op" value="ADICIONAR">

                <h3>Tamanho</h3>

                <div class="opcao">
                    <input type="radio" name="tamanho" value="PEQUENO" required>
                    <label>Pequeno</label>
                </div>

                <div class="opcao">
                    <input type="radio" name="tamanho" value="MEDIO">
                    <label>Medio</label>
                </div>

                <div class="opcao">
                    <input type="radio" name="tamanho" value="GRANDE">
                    <label>Grande</label>
                </div>

                <h3>Complementos</h3>

                <div class="opcao">
                    <input type="checkbox" name="adicional" value="MANGA">
                    <label>Manga</label>
                </div>

                <div class="opcao">
                    <input type="checkbox" name="adicional" value="GRANOLA">
                    <label>Granola</label>
                </div>

                <div class="opcao">
                    <input type="checkbox" name="adicional" value="PACOCA">
                    <label>Pacoca</label>
                </div>

                <div class="opcao">
                    <input type="checkbox" name="adicional" value="NUTELLA">
                    <label>Nutella</label>
                </div>

                <div class="opcao">
                    <input type="checkbox" name="adicional" value="LEITECONDENSADO">
                    <label>Leite Condensado</label>
                </div>

                <button type="submit" class="btn">
                    ADICIONAR AO CARRINHO
                </button>

            </form>

        </div>

    </div>

</body>
</html>