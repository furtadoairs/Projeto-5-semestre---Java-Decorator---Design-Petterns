<style>
body{
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:linear-gradient(135deg,#6a0dad,#8a2be2,#c71585);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

.cardPagamento{
    background:white;
    width:450px;
    padding:35px;
    border-radius:25px;
    box-shadow:0 15px 35px rgba(0,0,0,.25);
    text-align:center;
}

.titulo{
    color:#6a0dad;
    font-size:38px;
    margin-bottom:10px;
}

.subtitulo{
    color:#666;
    margin-bottom:25px;
}

.selectPagamento{
    width:100%;
    padding:15px;
    border-radius:12px;
    border:2px solid #ddd;
    font-size:16px;
    outline:none;
    transition:.3s;
}

.selectPagamento:focus{
    border-color:#8a2be2;
    box-shadow:0 0 10px rgba(138,43,226,.3);
}

.btnConfirmar{
    width:100%;
    margin-top:25px;
    padding:15px;
    border:none;
    border-radius:15px;
    background:linear-gradient(135deg,#28a745,#1e7e34);
    color:white;
    font-size:17px;
    font-weight:bold;
    cursor:pointer;
    transition:.3s;
    box-shadow:0 5px 20px rgba(40,167,69,.4);
}

.btnConfirmar:hover{
    transform:translateY(-3px);
    box-shadow:0 10px 25px rgba(40,167,69,.5);
}
</style>

<div class="cardPagamento">

    <h1 class="titulo"> Pagamento</h1>

    <p class="subtitulo">
        Escolha a forma de pagamento para concluir seu pedido
    </p>

    <form action="PedidoController" method="post">

        <input type="hidden"
               name="op"
               value="CONFIRMAR">

        <select name="pagamento"
                class="selectPagamento"
                required>

            <option value="">
                Selecione uma op��o
            </option>

            <option value="PIX">
                 PIX
            </option>

            <option value="Cartao">
                 Cartao
            </option>

            <option value="Dinheiro">
                 Dinheiro
            </option>

        </select>

        <button type="submit"
                class="btnConfirmar">

            Confirmar Pedido

        </button>

    </form>

</div>