<%@page contentType="text/html" pageEncoding="UTF-8"%>

<h1>ERRO</h1>

<p>
    <%= request.getAttribute("msg")%>
</p>