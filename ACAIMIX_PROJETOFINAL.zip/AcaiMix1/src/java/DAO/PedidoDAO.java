/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Pedido;
import util.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    public void cadastrar(Pedido p)
            throws ClassNotFoundException, SQLException {

        Connection con = Conexao.getConexaoMySQL();

        PreparedStatement comando
                = con.prepareStatement("insert into pedido "+ "(descricao, dataPedido, valorTotal, status, pagamento) "+ "values (?, ?, ?, ?)");
        comando.setTimestamp(1,
                new Timestamp(p.getDataPedido().getTime()));
        comando.setDouble(2, p.getValorTotal());
        comando.setString(3, p.getStatus());
        comando.setString(4, p.getPagamento());

        comando.executeUpdate();

        comando.close();
        con.close();
    }
}
