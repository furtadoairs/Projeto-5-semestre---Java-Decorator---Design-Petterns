package controller;

import model.Pedido;
import dao.PedidoDAO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import model.AcaiGrande;
import model.AcaiMedio;
import model.AcaiPequeno;
import model.Alimento;
import model.Granola;
import model.LeiteCondensado;
import model.Manga;
import model.Nutella;
import model.Pacoca;

@WebServlet("/PedidoController")
public class PedidoController extends HttpServlet {

    protected void processRequest(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        List<Pedido> carrinho
                = (List<Pedido>) session.getAttribute("carrinho");

        if (carrinho == null) {
            carrinho = new ArrayList<>();
        }

        String op = request.getParameter("op");

        if (op == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        try {

            switch (op) {

                case "ADICIONAR":
                    adicionarAoCarrinho(
                            request,
                            response,
                            session,
                            carrinho);
                    break;

                case "VER_CARRINHO":

                    request.setAttribute(
                            "listaPedidos",
                            carrinho);

                    request.getRequestDispatcher(
                            "carrinho.jsp")
                            .forward(request, response);

                    break;

                case "REMOVER":
                    removerDoCarrinho(
                            request,
                            response,
                            session,
                            carrinho);
                    break;

                case "FINALIZAR":
                    finalizarPedido(
                            request,
                            response,
                            session,
                            carrinho);
                    break;

                case "CONFIRMAR":
                    confirmarPagamento(
                            request,
                            response,
                            session,
                            carrinho);
                    break;
            }

        } catch (Exception ex) {

            request.setAttribute(
                    "msg",
                    ex.getMessage());

            request.getRequestDispatcher(
                    "erro.jsp")
                    .forward(request, response);
        }
    }

    private void adicionarAoCarrinho(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session,
            List<Pedido> carrinho)
            throws Exception {

        String tamanho
                = request.getParameter("tamanho");

        String[] adicionais
                = request.getParameterValues("adicional");

        Alimento alimento;

        switch (tamanho) {

            case "PEQUENO":
                alimento = new AcaiPequeno();
                break;

            case "MEDIO":
                alimento = new AcaiMedio();
                break;

            default:
                alimento = new AcaiGrande();
        }

        if (adicionais != null) {

            for (String item : adicionais) {

                switch (item.toUpperCase()) {

                    case "MANGA":
                        alimento = new Manga(alimento);
                        break;

                    case "GRANOLA":
                        alimento = new Granola(alimento);
                        break;

                    case "PACOCA":
                        alimento = new Pacoca(alimento);
                        break;

                    case "NUTELLA":
                        alimento = new Nutella(alimento);
                        break;

                    case "LEITE CONDENSADO":
                    case "LEITECONDENSADO":
                        alimento = new LeiteCondensado(alimento);
                        break;
                }
            }
        }

        Pedido pedido = new Pedido();

        pedido.setDescricao(
                alimento.getDescricao());

        pedido.setValorTotal(
                alimento.getCusto());

        pedido.setStatus(
                "EM PREPARO");

        pedido.setDataPedido(
                new Date());

        carrinho.add(pedido);

        session.setAttribute(
                "carrinho",
                carrinho);

        request.setAttribute(
                "listaPedidos",
                carrinho);

        request.getRequestDispatcher(
                "carrinho.jsp")
                .forward(request, response);
    }

    private void removerDoCarrinho(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session,
            List<Pedido> carrinho)
            throws Exception {

        int indice
                = Integer.parseInt(
                        request.getParameter("indice"));

        carrinho.remove(indice);

        session.setAttribute(
                "carrinho",
                carrinho);

        response.sendRedirect(
                "PedidoController?op=VER_CARRINHO");
    }

    private void finalizarPedido(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session,
            List<Pedido> carrinho)
            throws Exception {

        double total = 0;

        for (Pedido item : carrinho) {
            total += item.getValorTotal();
        }

        request.setAttribute(
                "valorTotal",
                total);

        request.getRequestDispatcher(
                "pagamento.jsp")
                .forward(request, response);
    }

    private void confirmarPagamento(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session,
            List<Pedido> carrinho
    )
            throws Exception {

        String pagamento
                = request.getParameter("pagamento");

        double total = 0;

        for (Pedido item : carrinho) {
            total += item.getValorTotal();
        }
        Pedido pedido = new Pedido();
        pedido.setDataPedido(new Date());
        pedido.setValorTotal(total);
        pedido.setPagamento(pagamento);
        pedido.setStatus("CONCLUIDO");

        new PedidoDAO().cadastrar(pedido);
        request.setAttribute(
                "formaPagamento",
                pagamento);
        request.setAttribute(
                "valorTotal",
                total);
        session.removeAttribute(
                "carrinho");
        request.getRequestDispatcher(
                "pagamentoFinalizado.jsp")
                .forward(request, response);
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        processRequest(request, response);
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        processRequest(request, response);
    }

}
