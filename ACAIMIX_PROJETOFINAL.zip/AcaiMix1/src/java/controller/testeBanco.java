/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author famyo
 */
import java.sql.Connection;
import util.Conexao;

public class testeBanco{

    public static void main(String[] args) {

        try {
            Connection con = Conexao.getConexaoMySQL();

            if (con != null) {
                System.out.println("✅ Conexão OK com o banco!");
            }

            con.close();

        } catch (Exception e) {
            System.out.println("❌ Erro na conexão:");
            e.printStackTrace();
        }
    }
}