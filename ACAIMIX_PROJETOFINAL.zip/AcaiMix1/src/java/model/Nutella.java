/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Nutella extends AdicionaisDecorator {

    public Nutella(Alimento alimento) {
        super(alimento);
    }

    @Override
    public double getCusto() {
        return alimentoDecorator.getCusto() + 5.0;
    }

    @Override
    public String getDescricao() {
        return alimentoDecorator.getDescricao() + ", Nutella";
    }
}
