/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author igorn
 */
public class AdicionaisDecorator implements Alimento {
    protected Alimento alimentoDecorator;
    
    public AdicionaisDecorator(Alimento alimentoDecorator){
        this.alimentoDecorator = alimentoDecorator;
    }
    
    @Override
    public String getDescricao() {
        return alimentoDecorator.getDescricao();
    }

    @Override
    public double getCusto() {
        return alimentoDecorator.getCusto();
    }
}
