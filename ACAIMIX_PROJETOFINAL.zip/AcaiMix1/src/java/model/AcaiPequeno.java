/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author igorn
 */
public class AcaiPequeno implements Alimento {
    private String descricao;
    private double precobase;
    
    public AcaiPequeno(){
        descricao = "Acai Pequeno";
        precobase = 10;
    }
    
    @Override
    public String getDescricao(){
        return descricao;
    }
    
    @Override
    public double getCusto(){
        return precobase;
    }
    
}
