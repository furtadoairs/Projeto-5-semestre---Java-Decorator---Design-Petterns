/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author igorn
 */
public class Granola extends AdicionaisDecorator{
    
    public Granola(Alimento alimento){
        super(alimento);
    }
    
    @Override
    public double getCusto() {
        return alimentoDecorator.getCusto() + 2.0;
    }

    @Override
    public String getDescricao() {
        return alimentoDecorator.getDescricao() + ", Granola";
    }
}
