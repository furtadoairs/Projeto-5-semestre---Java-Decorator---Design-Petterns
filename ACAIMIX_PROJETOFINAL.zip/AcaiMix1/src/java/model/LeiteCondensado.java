/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class LeiteCondensado extends AdicionaisDecorator {

    public LeiteCondensado(Alimento alimento) {
        super(alimento);
    }

    @Override
    public double getCusto() {
        return alimentoDecorator.getCusto() + 3.5;
    }

    @Override
    public String getDescricao() {
        return alimentoDecorator.getDescricao() + ", Leite Condensado";
    }
}
