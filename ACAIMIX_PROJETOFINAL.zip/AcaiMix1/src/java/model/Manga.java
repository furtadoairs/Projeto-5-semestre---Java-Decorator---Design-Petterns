/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Manga extends AdicionaisDecorator {

    public Manga(Alimento alimento) {
        super(alimento);
    }

    @Override
    public double getCusto() {
        return alimentoDecorator.getCusto() + 2.5;
    }

    @Override
    public String getDescricao() {
        return alimentoDecorator.getDescricao() + ", Manga";
    }
}
