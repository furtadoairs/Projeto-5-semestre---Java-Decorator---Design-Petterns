/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author igorn
 */
public class AcaiMedio implements Alimento {
    private String descricao;
    private double precobase;
    
    public AcaiMedio(){
        descricao = "Acai Medio";
        precobase = 15;
    }
    
    @Override
    public String getDescricao(){
        return descricao;
    }
    
    @Override
    public double getCusto(){
        return precobase;
    }
}
